from django.contrib import admin
from .models import Student_detail


# Register your models here.
admin.site.register(Student_detail)